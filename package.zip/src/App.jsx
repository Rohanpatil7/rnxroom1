import React, { useEffect, useState } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import Navbar from "./components/Navbar.jsx";
import Home from "./pages/Home.jsx";
import AllRooms from "./pages/AllRooms.jsx";
import Booking from "./pages/Booking.jsx";
import { getHotelDetails } from "./api/api_services.js";
import PaySuccess from "./pages/Paysuccess.jsx";
import PayFailure from "./pages/Payfailure.jsx";
import {BallTriangle} from "react-loader-spinner";


// NEW IMPORTS
import AdminLayout from './admin/components/AdminLayout';
import Dashboard from './admin/pages/Dashboard';
import Login from './admin/pages/Login';
import Bookings from './admin/pages/Bookings'; // Import this
import Rooms from './admin/pages/Rooms';       // Import this

// Create a simple protected route wrapper
const ProtectedAdminRoute = ({ children }) => {
    const isAuthenticated = sessionStorage.getItem("adminToken"); 
    return isAuthenticated ? children : <Navigate to="/admin/login" replace />;
};


function App() {
  const [hotelData, setHotelData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // 1. DETERMINE IF WE ARE ON AN ADMIN ROUTE
  // We use window.location because we are inside the Router in main.jsx, 
  // but using window is safer for the initial render check here.
  const isAdmin = window.location.pathname.startsWith('/admin');

   const getQueryParam = (name) => {
    let query = window.location.search;
    if (!query && window.location.hash.includes("?")) {
      query = window.location.hash.split("?")[1];
    }
    const params = new URLSearchParams(query);
    return params.get(name);
  };

  // ✅ Get URL parameter (already decoded by URLSearchParams)
  const urlParam = getQueryParam("parameter");
  
  // ✅ Get stored parameter
  const storedParam = localStorage.getItem("hotelParam");
  
  // ✅ Use URL param if available, otherwise stored
  const hotelParam = urlParam || storedParam;

   // ✅ Save to localStorage immediately if URL param exists
  if (urlParam && urlParam !== storedParam) {
    localStorage.setItem("hotelParam", urlParam);
    // console.log("✅ Saved parameter to localStorage:", urlParam);
  }


  // console.log("🔍 Debug Info:", {
  //   urlParam,
  //   storedParam,
  //   hotelParam,
  //   urlLength: urlParam?.length,
  //   storedLength: storedParam?.length
  // });

  useEffect(() => {
    if (isAdmin) return;

    const fetchHotelData = async () => {
      if (!hotelParam) {
        setError("Trouble to find hotel.");
        return;
      }

      try {
        setLoading(true);

        // ✅ Save DECODED parameter from URL
        if (urlParam) {
          localStorage.setItem("hotelParam", urlParam);
          // console.log("✅ Saved to localStorage:", urlParam);
        }

        // ✅ Use parameter directly (already decoded by URLSearchParams)
        const data = await getHotelDetails(hotelParam);

        if (data?.result?.[0]) {
          if (data.result[0].Error) {
            setError(` ${data.result[0].Error}`);
            
            // ✅ Clear localStorage if API says invalid
            if (data.result[0].Error.includes("Truble to find hotel")) {
              // localStorage.removeItem("hotelParam");
            }
          } else {
            setHotelData(data.result[0]);
            setError(null);
          }
        } else {
          setError("Received invalid data format from the hotel details API.");
        }
      } catch (err) {
        console.error("Failed to fetch hotel data:", err);
        setError(err.message || "An unknown network error occurred.");
      } finally {
        setLoading(false);
      }
    };

    fetchHotelData();
  }, [hotelParam, urlParam,isAdmin]);

  // ✅ Loading UI
  if (loading && !isAdmin) {
    return (
      <div className="flex items-center justify-center h-screen text-xl font-semibold">
        <BallTriangle
      height={100}
      width={100}
      radius={5}
      color="#3d52f2"
      ariaLabel="ball-triangle-loading"
      wrapperStyle={{}}
      wrapperClass=""
      visible={true}
/>
      </div>
    );
  }

  // ✅ Error UI
  if (error && !isAdmin) {
    return (
      <div className="flex items-center justify-center h-screen text-xl font-semibold text-red-600">
        Error: {error}
      </div>
    );
  }

  // ✅ Initial (no data) UI
  if (!hotelData && !isAdmin) {
    return (
      <div className="flex items-center justify-center h-screen text-xl font-semibold">
        Please provide a hotel parameter in the URL.
      </div>
    );
  }

  return (
    <div className="bg-gray-50">
      {/* NOTE: We only show User Navbar if NOT in admin mode. 
          Alternatively, move Navbar inside the user routes only.
      */}
      {!window.location.pathname.startsWith('/admin') && <Navbar hotelData={hotelData} />}
      
      <div className="h-fit relative">
        <Routes>
            {/* --- USER ROUTES --- */}
            <Route path="/" element={<Home hotelData={hotelData} />} />
            <Route path="/allrooms" element={<AllRooms hotelData={hotelData} room />} />
            <Route path="/booking/new" element={<Booking hotelData={hotelData} />} />
            <Route path="/payment-success" element={<PaySuccess hotelData={hotelData}/>} />
            <Route path="/payment-failure" element={<PayFailure />} />

            {/* --- ADMIN ROUTES --- */}
            <Route path="/admin/login" element={<Login />} />
            
            <Route path="/admin" element={
                <ProtectedAdminRoute>
                    <AdminLayout />
                </ProtectedAdminRoute>
            }>
                {/* Nested Admin Routes */}
                <Route index element={<Navigate to="dashboard" />} />
                <Route path="dashboard" element={<Dashboard />} />
                {/* Use the new components here */}
                <Route path="bookings" element={<Bookings />} /> 
                <Route path="rooms" element={<Rooms />} />
            </Route>

            {/* Fallback */}
            <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
    </div>
  );
}

export default App;
