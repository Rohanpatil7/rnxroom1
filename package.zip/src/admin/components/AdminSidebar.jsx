import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  CalendarCheck, 
  BedDouble, 
  LogOut, 
  ChevronLeft,
  ChevronRight,
  User,
  Settings,
  X
} from 'lucide-react';

const AdminSidebar = ({ 
  isSidebarOpen, 
  setSidebarOpen, 
  isMobileMenuOpen, 
  setIsMobileMenuOpen, 
  handleLogout 
}) => {
  return (
    <>
      {/* Mobile Backdrop Overlay */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 z-40 bg-slate-900/20 backdrop-blur-sm md:hidden transition-opacity"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside 
        className={`
          fixed inset-y-0 left-0 z-50 bg-white border-r border-slate-200 shadow-[2px_0_8px_-4px_rgba(0,0,0,0.05)] transition-all duration-300 ease-in-out flex flex-col
          /* Mobile: Fixed width */
          w-72 ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}
          /* Desktop: Relative, Collapsible */
          md:relative md:translate-x-0 
          ${isSidebarOpen ? 'md:w-72' : 'md:w-[80px]'}
        `}
      >
        {/* Header / Logo */}
        <div className="h-18 flex items-center px-6 py-5 mb-2">
          <div className="flex items-center gap-3 overflow-hidden">
             <div className="w-9 h-9 rounded-xl bg-indigo-600 flex items-center justify-center shrink-0 shadow-indigo-100 shadow-md">
                <span className="font-bold text-white text-lg">H</span>
             </div>
             <div className={`transition-opacity duration-300 ${isSidebarOpen ? 'opacity-100' : 'opacity-0 md:hidden'}`}>
                <h1 className="font-bold text-slate-800 text-lg tracking-tight leading-tight">HotelAdmin</h1>
                <p className="text-[10px] text-slate-400 font-medium uppercase tracking-wider">Management</p>
             </div>
          </div>
          
          {/* Mobile Close */}
          <button 
            onClick={() => setIsMobileMenuOpen(false)}
            className="md:hidden ml-auto text-slate-400 hover:text-slate-600"
          >
            <X size={20} />
          </button>
        </div>

        {/* Desktop Toggle Button (Floating on Border) */}
        <button 
            onClick={() => setSidebarOpen(!isSidebarOpen)} 
            className="hidden md:flex absolute -right-3 top-8 bg-white text-slate-400 hover:text-indigo-600 p-1.5 rounded-full shadow-md border border-slate-100 z-50 transition-all hover:scale-110"
        >
            {isSidebarOpen ? <ChevronLeft size={14} /> : <ChevronRight size={14} />}
        </button>

        {/* Navigation */}
        <nav className="flex-1 px-3 space-y-1 overflow-y-auto custom-scrollbar py-2">
            <SidebarSection title="Overview" isOpen={isSidebarOpen} />
            
            <SidebarLink 
                to="/admin/dashboard" 
                icon={LayoutDashboard} 
                label="Dashboard" 
                isOpen={isSidebarOpen} 
            />
            <SidebarLink 
                to="/admin/bookings" 
                icon={CalendarCheck} 
                label="Bookings" 
                isOpen={isSidebarOpen}
                // badge="12"
            />
            <SidebarLink 
                to="/admin/rooms" 
                icon={BedDouble} 
                label="Rooms & Rates" 
                isOpen={isSidebarOpen}
            />

            <div className="my-4 border-t border-slate-100 mx-2"></div>
            
            <SidebarSection title="Settings" isOpen={isSidebarOpen} />
             <SidebarLink 
                to="/admin/settings" 
                icon={Settings} 
                label="Configuration" 
                isOpen={isSidebarOpen}
            />
        </nav>

        {/* User Profile Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50/50">
            <div className={`flex items-center gap-3 ${!isSidebarOpen && 'md:justify-center'}`}>
                <div className="w-9 h-9 rounded-full bg-white border border-slate-200 flex items-center justify-center shrink-0 shadow-sm text-slate-500">
                    <User size={18} />
                </div>
                {isSidebarOpen && (
                    <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-slate-700 truncate">Admin User</p>
                        <p className="text-xs text-slate-500 truncate">admin@hotel.com</p>
                    </div>
                )}
                {isSidebarOpen && (
                    <button 
                        onClick={handleLogout}
                        className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                        title="Sign Out"
                    >
                        <LogOut size={16} />
                    </button>
                )}
            </div>
        </div>
      </aside>
    </>
  );
};

// --- Sub Components ---

const SidebarSection = ({ title, isOpen }) => (
  <div className={`px-4 mb-2 mt-4 transition-all duration-300 ${!isOpen ? 'md:opacity-0 md:h-0 overflow-hidden' : 'opacity-100'}`}>
      <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest">{title}</p>
  </div>
);

const SidebarLink = ({ to, icon: Icon, label, isOpen, badge }) => (
    <NavLink 
        to={to} 
        className={({ isActive }) => `
            group flex items-center gap-3 px-3 py-2.5 mx-1 rounded-lg transition-all duration-200 font-medium relative
            ${isActive 
                ? 'bg-indigo-50 text-indigo-600 shadow-sm' 
                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
            }
            ${!isOpen && 'md:justify-center md:px-2'}
        `}
    >
        <Icon size={20} className={`shrink-0 transition-colors ${!isOpen ? 'md:w-6 md:h-6' : ''}`} />
        
        <span className={`
            whitespace-nowrap transition-all duration-300 origin-left
            ${!isOpen 
                ? 'md:hidden' 
                : 'block'
            }
        `}>
            {label}
        </span>

        {/* Badge for notifications */}
        {badge && isOpen && (
          <span className="ml-auto bg-indigo-100 text-indigo-600 text-[10px] font-bold px-2 py-0.5 rounded-full">
            {badge}
          </span>
        )}

        {/* Tooltip for collapsed state */}
        {!isOpen && (
            <div className="hidden md:block absolute left-full ml-3 px-2 py-1 bg-slate-800 text-white text-xs rounded-md opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 shadow-lg translate-x-[-10px] group-hover:translate-x-0 transition-all">
                {label}
            </div>
        )}
    </NavLink>
);

export default AdminSidebar;